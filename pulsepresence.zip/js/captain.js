/* ============================================================
   PulsePresence — CO-CAPTAIN
   Tactical decisions that appear between overs.
   You vote BEFORE the captain acts, then see if you matched.
============================================================ */

const Captain = {
  used: new Set(),       // decision IDs already shown
  activeDecision: null,
  picked: null,
};

// ============================================================
// Trigger a captain prompt if one matches current context
// ============================================================
function maybeShowCaptainPrompt(state, ball){
  if (!ball) return;
  // Trigger at the END of an over only (last ball)
  if (ball.ball < 6 && ball.type !== 'wicket') return;

  // Look for matching decision
  const decision = CAPTAIN_DECISIONS.find(d =>
    d.triggerOver === ball.over &&
    d.triggerInnings === ball.innings &&
    !Captain.used.has(d.triggerInnings + '-' + d.triggerOver)
  );

  if (!decision) return;
  Captain.used.add(decision.triggerInnings + '-' + decision.triggerOver);
  showCaptainPrompt(decision);
}

// ============================================================
// Render the prompt UI
// ============================================================
function showCaptainPrompt(decision){
  Captain.activeDecision = decision;
  Captain.picked = null;

  document.getElementById('captain-status').textContent = 'YOUR CALL · 12s';

  const card = document.getElementById('captain-card');
  card.innerHTML = `
    <div class="captain-prompt">
      <div class="captain-question">${decision.question}</div>
      <div class="captain-context">${decision.context}</div>
      <div class="captain-options">
        ${decision.options.map((opt, i) => `
          <button class="captain-option" data-idx="${i}">
            <span class="captain-option-label">${opt.label}</span>
            <span class="captain-option-pct">— %</span>
            <div class="captain-option-bar" style="width:0%"></div>
          </button>
        `).join('')}
      </div>
      <div class="captain-result" id="captain-result" style="display:none"></div>
    </div>
  `;

  // Wire up clicks
  card.querySelectorAll('.captain-option').forEach(btn => {
    btn.addEventListener('click', () => {
      if (Captain.picked !== null) return;
      Captain.picked = parseInt(btn.dataset.idx);
      btn.classList.add('picked');
      revealCaptainResult();
    });
  });

  // Auto-reveal after ~12 seconds if user didn't pick
  setTimeout(() => {
    if (Captain.activeDecision === decision && Captain.picked === null){
      revealCaptainResult();
    }
  }, 12000);
}

// ============================================================
// Reveal what the actual captain did + crowd's call
// ============================================================
function revealCaptainResult(){
  const decision = Captain.activeDecision;
  if (!decision) return;

  const card = document.getElementById('captain-card');
  const buttons = card.querySelectorAll('.captain-option');

  buttons.forEach((btn, i) => {
    const opt = decision.options[i];
    btn.classList.add('revealed');
    btn.querySelector('.captain-option-pct').textContent = opt.fanPct + '%';
    btn.querySelector('.captain-option-bar').style.width = opt.fanPct + '%';
    if (opt.actual) btn.classList.add('actual');
  });

  const userMatched = Captain.picked !== null && decision.options[Captain.picked].actual;
  const resultEl = document.getElementById('captain-result');
  resultEl.style.display = 'block';

  if (Captain.picked === null){
    resultEl.innerHTML = `<div class="captain-result-correct">DECISION REVEALED</div>${decision.outcome}`;
  } else if (userMatched){
    resultEl.innerHTML = `<div class="captain-result-correct">✓ YOU AND THE CAPTAIN AGREE</div>${decision.outcome}`;
  } else {
    resultEl.innerHTML = `<div class="captain-result-correct" style="color:var(--ink-dim)">DIFFERENT CALL</div>${decision.outcome}`;
  }

  document.getElementById('captain-status').textContent = 'REVEALED';

  // Reset to empty state after a while
  setTimeout(() => {
    if (Captain.activeDecision === decision){
      Captain.activeDecision = null;
      const card = document.getElementById('captain-card');
      card.innerHTML = `
        <div class="captain-empty">
          <div class="captain-empty-icon">▲</div>
          <div class="captain-empty-text">Next tactical decision coming soon. Stay sharp.</div>
        </div>
      `;
      document.getElementById('captain-status').textContent = 'STANDBY';
    }
  }, 8000);
}
