/* ============================================================
   PulsePresence — APP (entry point)
============================================================ */

const state = {
  ballIdx: -1,
  inningsScores: [{ runs: 0, wkts: 0 }, { runs: 0, wkts: 0 }],
  currentInnings: 0,
  balls: [],
  isPlaying: false,
  speed: CONFIG.DEFAULT_SPEED,
  wp: 52,
  userTeam: 'neutral',
  intervalId: null,
};

// ============================================================
// Match loop scheduler
// ============================================================
function startTicker(){
  if (state.intervalId) clearInterval(state.intervalId);
  state.intervalId = setInterval(() => {
    if (!state.isPlaying) return;
    if (state.ballIdx >= ALL_BALLS.length - 1){
      finishMatch();
      return;
    }
    bowlBall(state);
  }, state.speed);
}

function finishMatch(){
  state.isPlaying = false;
  clearInterval(state.intervalId);
  document.getElementById('play-btn').textContent = '▶ REPLAY';

  const f1 = state.inningsScores[0];
  const f2 = state.inningsScores[1];
  showToast(`MATCH OVER · ${shortTeam(TEAM1)} ${f1.runs}/${f1.wkts} · ${shortTeam(TEAM2)} ${f2.runs}/${f2.wkts}`);

  // Final narrative beat
  document.getElementById('director-text').innerHTML =
    `<em>The match is over.</em> You were here for every ball. Two hundred eyes on one field. <strong>This is presence.</strong>`;
  document.getElementById('director-chapter').textContent = 'EPILOGUE';
  document.getElementById('director-emotion').textContent = 'CATHARSIS';
}

// ============================================================
// Enter the stadium (intro CTA)
// ============================================================
function enterStadium(){
  document.getElementById('intro').classList.add('hide');
  setTimeout(() => {
    state.isPlaying = true;
    document.getElementById('play-btn').textContent = '⏸ PAUSE';
    Sentiment.start(state);
    Presence.animate();
    initWave();

    // Opening narrative
    generateNarrative(state);

    // Start ticking
    startTicker();

    showToast('You are in.');
  }, 800);
}

// ============================================================
// Wire events
// ============================================================
function wireEvents(){
  // Play/pause
  document.getElementById('play-btn').addEventListener('click', () => {
    state.isPlaying = !state.isPlaying;
    document.getElementById('play-btn').textContent = state.isPlaying ? '⏸ PAUSE' : '▶ PLAY';
  });

  // Speed
  document.querySelectorAll('.speed-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.speed-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.speed = parseInt(btn.dataset.speed);
      startTicker(); // restart with new interval
    });
  });

  // Team picker
  document.querySelectorAll('.team-pick-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.team-pick-btn').forEach(b => b.classList.remove('picked'));
      btn.classList.add('picked');
      state.userTeam = btn.dataset.team;
      document.getElementById('director-team').textContent = state.userTeam.toUpperCase();
      // Enable CTA
      document.getElementById('intro-cta').disabled = false;
    });
  });

  // Ask the director (Enter to send)
  document.getElementById('ask-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') askDirector();
  });

  // Initialize theatre reactions
  initTheatre();
}

// ============================================================
// Toast helper
// ============================================================
function showToast(text){
  const t = document.getElementById('toast');
  t.textContent = text;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

// ============================================================
// Load match data
// ============================================================
async function loadMatch(){
  try {
    const res = await fetch(CONFIG.MATCH_DATA_PATH);
    if (!res.ok) throw new Error('Failed to load match.json');
    MATCH_DATA_RAW = await res.json();
  } catch (e) {
    console.error('Match load failed:', e);
    document.getElementById('intro-match-teams').textContent = 'Match data failed to load';
    return false;
  }

  ALL_BALLS = parseCricsheet(MATCH_DATA_RAW);
  TEAM1 = MATCH_DATA_RAW.info.teams[1];  // bats first
  TEAM2 = MATCH_DATA_RAW.info.teams[0];
  VENUE = MATCH_DATA_RAW.info.venue;

  // Intro display
  document.getElementById('intro-match-teams').textContent =
    `${shortTeam(TEAM2)} vs ${shortTeam(TEAM1)}`;
  document.getElementById('intro-match-venue').textContent =
    `${VENUE.split(',')[0].toUpperCase()} · ${MATCH_DATA_RAW.info.dates[0]}`;

  // AI status pill
  const aiEl = document.getElementById('intro-ai');
  if (CONFIG.AI_ENABLED){
    aiEl.className = 'intro-ai on';
    aiEl.textContent = '✓ AI MATCH DIRECTOR · ONLINE';
  } else {
    aiEl.className = 'intro-ai off';
    aiEl.textContent = '◯ AI OFFLINE · paste OpenAI key in js/config.js';
    document.getElementById('director-source').textContent = 'SCRIPTED';
  }

  return true;
}

// ============================================================
// Boot
// ============================================================
window.addEventListener('DOMContentLoaded', async () => {
  wireEvents();
  await loadMatch();
});
