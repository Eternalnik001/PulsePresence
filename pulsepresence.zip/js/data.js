/* ============================================================
   PulsePresence — DATA MODULE
============================================================ */

let MATCH_DATA_RAW = null;
let ALL_BALLS = [];
let TEAM1 = "";
let TEAM2 = "";
let VENUE = "";

// ============================================================
// Parse Cricsheet JSON → flat ball events
// ============================================================
function parseCricsheet(data){
  const balls = [];
  data.innings.forEach((inn, inningsIdx) => {
    inn.overs.forEach(over => {
      over.deliveries.forEach((d, ballIdx) => {
        const isWicket = !!d.wickets;
        const runs = d.runs.batter;
        let type;
        if (isWicket)        type = 'wicket';
        else if (runs === 6) type = 'six';
        else if (runs === 4) type = 'four';
        else if (runs === 0) type = 'dot';
        else if (runs === 1) type = 'one';
        else if (runs === 2) type = 'two';
        else                 type = 'other';

        balls.push({
          innings: inningsIdx,
          battingTeam: inn.team,
          over: over.over,
          ball: ballIdx + 1,
          batter: d.batter,
          bowler: d.bowler,
          runs: isWicket ? 'W' : runs,
          type: type,
          wicketKind: isWicket ? d.wickets[0].kind : null,
          playerOut: isWicket ? d.wickets[0].player_out : null
        });
      });
    });
  });
  return balls;
}

function shortTeam(name){
  if (!name) return "—";
  if (name.includes('Bengaluru') || name.includes('Bangalore')) return 'RCB';
  if (name.includes('Chennai'))   return 'CSK';
  if (name.includes('Mumbai'))    return 'MI';
  if (name.includes('Kolkata'))   return 'KKR';
  if (name.includes('Delhi'))     return 'DC';
  if (name.includes('Punjab'))    return 'PBKS';
  if (name.includes('Rajasthan')) return 'RR';
  if (name.includes('Sunrisers')) return 'SRH';
  if (name.includes('Gujarat'))   return 'GT';
  if (name.includes('Lucknow'))   return 'LSG';
  return name.split(' ')[0].toUpperCase().substring(0, 3);
}

// ============================================================
// SENTIMENT MESSAGES — qualitative emotional expressions
// These are NOT chat banter. They're little emotional vignettes.
// ============================================================
const SENTIMENT_BY_EVENT = {
  six_rcb: [
    "Chinnaswamy is shaking. I can feel it through the screen.",
    "I'm not crying. You're crying.",
    "This is why I never miss an RCB game.",
    "GET IN. That's how you start an innings.",
    "Goosebumps. Literal goosebumps right now."
  ],
  six_csk: [
    "Thala said sit down, then stood up himself.",
    "Whistle Podu. WHISTLE PODU.",
    "Yellow brigade, are you watching this?",
    "MSD effect even when he's not batting.",
    "This is a different level of energy at Chepauk-South."
  ],
  wicket_rcb: [
    "We had to take that. Massive breakthrough.",
    "ROAR. The Chinnaswamy roar is unreal.",
    "Bowling unit finally clicking.",
    "Champions take wickets. We're taking wickets.",
  ],
  wicket_csk: [
    "Mahi pulled the rabbit out. Of course.",
    "That's why he's Captain Cool.",
    "Dhoni stumping = pure joy.",
    "Pathirana doing Pathirana things.",
  ],
  wicket_neutral: [
    "Whoever you support, that was a *good* ball.",
    "T20 cricket, man. One ball changes everything.",
    "Imagine being a bowler in this format. Brutal.",
  ],
  four_rcb: ["Threading the needle.", "Pure timing. Pure class.", "Bat speed unreal.", "Chase mode initiated."],
  four_csk: ["Old school four. Beautiful.", "Boundaries are coming.", "Chepauk classic.", "Patience paying off."],
  dot_pressure: [
    "Squeeze. Squeeze. Squeeze.",
    "Dot balls are gold in T20.",
    "Pressure is building. You can see it on the faces.",
    "This over could swing the match.",
  ],
  intro: [
    "Ready. Heart already racing.",
    "Long day at work, this is my therapy.",
    "Whole family on the couch. Phone in hand.",
    "Bring it on. Let's go.",
    "I am NERVOUS man. So much riding on this."
  ]
};

// ============================================================
// CAPTAIN DECISIONS — tactical questions tied to match moments
// These appear between overs (or after key events).
// `actual` = what the captain actually did (the answer)
// ============================================================
const CAPTAIN_DECISIONS = [
  {
    triggerOver: 1,
    triggerInnings: 0,
    question: "Powerplay attack — what's your move?",
    context: "Opener Gaikwad is set. 6 runs from 6 balls. Bowling change?",
    options: [
      { label: "Stick with Yash Dayal", actual: false, fanPct: 22 },
      { label: "Bring Siraj on for swing", actual: true, fanPct: 51 },
      { label: "Surprise — spin in powerplay", actual: false, fanPct: 27 }
    ],
    outcome: "Captain went with <strong>Siraj</strong>. Match the crowd's instinct."
  },
  {
    triggerOver: 3,
    triggerInnings: 0,
    question: "First wicket falls. New batter in. Field setting?",
    context: "Rahane just departed. New batter facing a moving ball.",
    options: [
      { label: "Attacking — 4 catchers", actual: true, fanPct: 64 },
      { label: "Stay defensive — singles plug", actual: false, fanPct: 21 },
      { label: "Bring on spin immediately", actual: false, fanPct: 15 }
    ],
    outcome: "Captain went <strong>attacking</strong>. You read the moment."
  },
  {
    triggerOver: 5,
    triggerInnings: 0,
    question: "End of powerplay coming. Risk or hold?",
    context: "26/1 after 4 overs. CSK have weathered the storm.",
    options: [
      { label: "Hold — build platform", actual: false, fanPct: 39 },
      { label: "Risk — go for boundary", actual: true, fanPct: 44 },
      { label: "Rotate strike, no boundaries", actual: false, fanPct: 17 }
    ],
    outcome: "Batters chose <strong>risk</strong>. Two boundaries in the over."
  },
  {
    triggerOver: 7,
    triggerInnings: 0,
    question: "Middle overs strategy?",
    context: "Spin coming on. Match in the balance.",
    options: [
      { label: "Aggression — take down the spinner", actual: false, fanPct: 34 },
      { label: "Calculated — rotate, attack one over", actual: true, fanPct: 48 },
      { label: "Caution — don't lose another wicket", actual: false, fanPct: 18 }
    ],
    outcome: "They went <strong>calculated</strong>. Smart cricket."
  },
  {
    triggerOver: 11,
    triggerInnings: 0,
    question: "Dhoni walks in. What does Faf do?",
    context: "MSD is at the crease. Crowd is on its feet. 5 balls left in the over.",
    options: [
      { label: "Pace him out — short ball line", actual: false, fanPct: 28 },
      { label: "Slow him down — yorker length", actual: true, fanPct: 53 },
      { label: "Tempt him — full and wide", actual: false, fanPct: 19 }
    ],
    outcome: "Yorkers came in. <strong>Mahi found them anyway.</strong> Of course."
  },
  {
    triggerOver: 1,
    triggerInnings: 1,
    question: "RCB chasing. Powerplay approach?",
    context: "Kohli and Faf out. The chase starts now.",
    options: [
      { label: "Go hard from ball 1", actual: true, fanPct: 47 },
      { label: "Anchor — Kohli plays himself in", actual: false, fanPct: 38 },
      { label: "Mixed — calculated risk", actual: false, fanPct: 15 }
    ],
    outcome: "RCB went <strong>hard</strong>. Kohli's intent was clear."
  },
  {
    triggerOver: 3,
    triggerInnings: 1,
    question: "Faf out. Patidar in. Tactical shift?",
    context: "Pressure building. Required rate climbing.",
    options: [
      { label: "Patidar takes charge", actual: true, fanPct: 41 },
      { label: "Kohli takes the burden", actual: false, fanPct: 44 },
      { label: "Both calm, build partnership", actual: false, fanPct: 15 }
    ],
    outcome: "Patidar attacked. Bold move that paid off."
  },
];
