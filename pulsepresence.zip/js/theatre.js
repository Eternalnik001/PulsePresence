/* ============================================================
   PulsePresence — KEY MOMENT THEATRE
   On six/wicket/special events, the screen transforms.
   Big headline, AI context, reactions, collective sentiment.
============================================================ */

const Theatre = {
  isOpen: false,
  currentBall: null,
};

// ============================================================
// Open the theatre for a key moment
// ============================================================
async function openTheatre(ball, state){
  if (Theatre.isOpen) return;
  Theatre.isOpen = true;
  Theatre.currentBall = ball;

  const theatre = document.getElementById('theatre');
  theatre.className = 'theatre';

  let headline, subhead, tagClass = ball.type;
  if (ball.type === 'six'){
    headline = 'SIX!';
    subhead = `${ball.batter} clears the rope`;
  } else if (ball.type === 'four'){
    headline = 'FOUR!';
    subhead = `${ball.batter} finds the gap`;
  } else if (ball.type === 'wicket'){
    headline = 'OUT';
    subhead = `${ball.playerOut} ${ball.wicketKind}, b ${ball.bowler}`;
  } else {
    headline = 'KEY MOMENT';
    subhead = '';
  }

  document.getElementById('theatre-tag').textContent = ball.type === 'wicket' ? 'BREAKTHROUGH' : 'KEY MOMENT';
  document.getElementById('theatre-headline').textContent = headline;
  document.getElementById('theatre-subhead').textContent = subhead;
  document.getElementById('theatre-context').innerHTML = '<span class="director-loading"></span> The director is analyzing...';

  // Collective sentiment bar
  renderCollectiveSentiment(ball);

  theatre.classList.add(tagClass);
  theatre.classList.add('show');

  // Fetch AI context (async, doesn't block opening)
  const aiContext = await generateMomentContext(ball, state);
  if (Theatre.currentBall === ball){
    document.getElementById('theatre-context').innerHTML = aiContext;
  }

  // Auto-close after a while if user doesn't dismiss
  setTimeout(() => {
    if (Theatre.currentBall === ball && Theatre.isOpen){
      closeTheatre();
    }
  }, 6500);
}

function closeTheatre(){
  document.getElementById('theatre').classList.remove('show');
  Theatre.isOpen = false;
  Theatre.currentBall = null;
}

// ============================================================
// Wire up reactions in the theatre
// ============================================================
function initTheatre(){
  document.querySelectorAll('.theatre-react').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const emoji = btn.dataset.emoji;
      spawnFloatingEmoji(emoji);
      if (Director && Theatre.currentBall){
        Director.userReactions.push({ ballIdx: Theatre.currentBall.over * 6 + Theatre.currentBall.ball, emoji });
      }
      if (navigator.vibrate) navigator.vibrate(10);
    });
  });
}

// ============================================================
// Spawn a floating emoji at a random burst point
// ============================================================
function spawnFloatingEmoji(emoji){
  const el = document.createElement('div');
  el.className = 'floating-emoji';
  el.textContent = emoji;
  el.style.left = (40 + Math.random() * 40) + 'vw';
  el.style.top = (50 + Math.random() * 20) + 'vh';
  document.getElementById('emoji-burst').appendChild(el);
  setTimeout(() => el.remove(), 2400);
}

// ============================================================
// AI context for a key moment
// ============================================================
async function generateMomentContext(ball, state){
  if (!CONFIG.AI_ENABLED){
    return fallbackMomentContext(ball, state);
  }

  const score = `${state.inningsScores[ball.innings].runs}/${state.inningsScores[ball.innings].wkts}`;
  const battingShort = shortTeam(ball.battingTeam);
  const userTeam = state.userTeam === 'neutral' ? 'a neutral fan' : `a ${state.userTeam.toUpperCase()} fan`;

  const ctx = `Cricket key moment.
Ball: ${ball.over}.${ball.ball}, Innings ${ball.innings + 1}.
What happened: ${ball.type === 'wicket' ? `WICKET — ${ball.playerOut} ${ball.wicketKind}, bowled by ${ball.bowler}` : `${ball.type.toUpperCase()} — ${ball.batter} off ${ball.bowler}`}.
Score now: ${battingShort} ${score}.
Win probability for ${battingShort}: ${Math.round(state.wp)}%.
Viewer is ${userTeam}.`;

  const sys = `You are the MATCH DIRECTOR. Write a 2-3 sentence context for this key moment. Capture WHY IT MATTERS — match impact, momentum, stakes. Vivid, intimate, second-person occasionally. Wrap key terms in <strong>. Use <em> for emotional emphasis. NO clichés.

Example:
"That's <strong>${ball.batter || 'his'}</strong>'s third six in this over. <em>The chase just shifted from probable to inevitable.</em> Look at the dugout — they're already standing."`;

  const result = await callGPT(sys, ctx, 110);
  return result || fallbackMomentContext(ball, state);
}

function fallbackMomentContext(ball, state){
  if (ball.type === 'six'){
    return `That's a <strong>statement shot</strong> from ${ball.batter}. The bowler's plan? Out the window. <em>Watch what happens next over.</em>`;
  }
  if (ball.type === 'wicket'){
    return `<strong>${ball.bowler}</strong> with the breakthrough. ${ball.playerOut} ${ball.wicketKind}. <em>The whole momentum just flipped.</em>`;
  }
  if (ball.type === 'four'){
    return `Clean. Crisp. Four runs. ${ball.batter} is timing it sweetly. <em>Confidence in every stroke.</em>`;
  }
  return `A pivotal ball. The match listens.`;
}

// ============================================================
// Collective sentiment bar (which emotion is dominant globally)
// ============================================================
function renderCollectiveSentiment(ball){
  const bar = document.getElementById('theatre-collective-bar');
  const label = document.querySelector('.theatre-collective-label');

  let segments;
  if (ball.type === 'six'){
    segments = [
      { emoji: '🔥', pct: 38, color: 'rgba(255,157,46,0.8)' },
      { emoji: '🤯', pct: 31, color: 'rgba(168,85,247,0.7)' },
      { emoji: '👏', pct: 19, color: 'rgba(16,185,129,0.7)' },
      { emoji: '🙏', pct: 12, color: 'rgba(160,160,160,0.5)' }
    ];
    label.textContent = (2.4 + Math.random() * 1.5).toFixed(1) + 'M FANS REACTED';
  } else if (ball.type === 'wicket'){
    segments = [
      { emoji: '🤯', pct: 34, color: 'rgba(168,85,247,0.7)' },
      { emoji: '🔥', pct: 28, color: 'rgba(255,157,46,0.8)' },
      { emoji: '💔', pct: 26, color: 'rgba(239,68,68,0.7)' },
      { emoji: '🙏', pct: 12, color: 'rgba(160,160,160,0.5)' }
    ];
    label.textContent = (3.1 + Math.random() * 0.9).toFixed(1) + 'M FANS REACTED';
  } else {
    segments = [
      { emoji: '🔥', pct: 35, color: 'rgba(255,157,46,0.8)' },
      { emoji: '👏', pct: 35, color: 'rgba(16,185,129,0.7)' },
      { emoji: '🙏', pct: 20, color: 'rgba(160,160,160,0.5)' },
      { emoji: '🤯', pct: 10, color: 'rgba(168,85,247,0.7)' }
    ];
    label.textContent = (1.2 + Math.random() * 0.6).toFixed(1) + 'M FANS REACTED';
  }

  bar.innerHTML = segments.map(s =>
    `<div class="theatre-collective-segment" style="flex: ${s.pct}; background: ${s.color}; color: rgba(255,255,255,0.9); font-weight: 700;">${s.emoji} ${s.pct}%</div>`
  ).join('');
}
