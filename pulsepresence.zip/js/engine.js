/* ============================================================
   PulsePresence — ENGINE
   Match progression, presence (emotion) model, sentiment feed.
   Note: no XP, no streaks, no leaderboard. By design.
============================================================ */

// ============================================================
// PRESENCE MODEL — 4 dimensions of collective emotion
// ============================================================
const Presence = {
  joy: 30,
  tension: 45,
  hope: 60,
  disbelief: 15,

  // Targets that decay toward
  joyT: 30,
  tensionT: 45,
  hopeT: 60,
  disbeliefT: 15,

  update(ball, state){
    // Compute deltas based on event
    if (ball.type === 'six'){
      this.joyT       = clamp(this.joyT + 35, 10, 95);
      this.tensionT   = clamp(this.tensionT - 8, 10, 95);
      this.hopeT      = clamp(this.hopeT + 20, 10, 95);
      this.disbeliefT = clamp(this.disbeliefT + 18, 10, 95);
    } else if (ball.type === 'wicket'){
      this.joyT       = clamp(this.joyT - 10, 10, 95);
      this.tensionT   = clamp(this.tensionT + 40, 10, 95);
      this.hopeT      = clamp(this.hopeT - 25, 10, 95);
      this.disbeliefT = clamp(this.disbeliefT + 30, 10, 95);
    } else if (ball.type === 'four'){
      this.joyT       = clamp(this.joyT + 18, 10, 95);
      this.tensionT   = clamp(this.tensionT - 5, 10, 95);
      this.hopeT      = clamp(this.hopeT + 12, 10, 95);
    } else if (ball.type === 'dot'){
      this.tensionT   = clamp(this.tensionT + 6, 10, 95);
      this.joyT       = clamp(this.joyT - 3, 10, 95);
    } else {
      this.joyT       = clamp(this.joyT + 3, 10, 95);
    }
  },

  animate(){
    this.joy       += (this.joyT - this.joy) * 0.08;
    this.tension   += (this.tensionT - this.tension) * 0.08;
    this.hope      += (this.hopeT - this.hope) * 0.08;
    this.disbelief += (this.disbeliefT - this.disbelief) * 0.08;

    // Slow drift toward baseline
    this.joyT       += ((30 - this.joyT) * 0.005);
    this.tensionT   += ((45 - this.tensionT) * 0.005);
    this.hopeT      += ((50 - this.hopeT) * 0.005);
    this.disbeliefT += ((15 - this.disbeliefT) * 0.008);

    // Update DOM
    document.getElementById('pulse-joy').style.width = this.joy + '%';
    document.getElementById('pulse-tension').style.width = this.tension + '%';
    document.getElementById('pulse-hope').style.width = this.hope + '%';
    document.getElementById('pulse-disbelief').style.width = this.disbelief + '%';

    // Pulse the central globe core based on overall intensity
    const intensity = (this.joy + this.tension + this.hope + this.disbelief) / 4;
    const core = document.getElementById('presence-core');
    if (core){
      const scale = 1 + (intensity - 40) / 200;
      core.style.transform = `scale(${scale})`;
    }

    requestAnimationFrame(() => this.animate());
  }
};

function clamp(v, min, max){ return Math.max(min, Math.min(max, v)); }

// ============================================================
// SENTIMENT FEED — emotional vignettes after events
// ============================================================
const Sentiment = {
  recentEvents: [],
  intervalId: null,

  start(state){
    // Initial mood
    setTimeout(() => this.add('rcb', SENTIMENT_BY_EVENT.intro[0]), 400);
    setTimeout(() => this.add('csk', SENTIMENT_BY_EVENT.intro[1]), 900);
    setTimeout(() => this.add('neutral', SENTIMENT_BY_EVENT.intro[2]), 1500);
    setTimeout(() => this.add('rcb', SENTIMENT_BY_EVENT.intro[3]), 2100);

    // Background drip when nothing big is happening
    this.intervalId = setInterval(() => {
      if (!state.isPlaying) return;
      const dotMessages = SENTIMENT_BY_EVENT.dot_pressure;
      const sides = ['rcb', 'csk', 'neutral'];
      const side = sides[Math.floor(Math.random() * sides.length)];
      const msg = dotMessages[Math.floor(Math.random() * dotMessages.length)];
      this.add(side, msg);
    }, 3500);
  },

  add(side, text){
    const feed = document.getElementById('sentiment-feed');
    if (!feed) return;
    const msg = document.createElement('div');
    msg.className = 'sentiment-msg';
    const userIdx = Math.floor(Math.random() * 9000) + 1000;
    msg.innerHTML = `
      <div class="sentiment-avatar ${side}">${side.toUpperCase()[0]}</div>
      <div class="sentiment-body">
        <span class="sentiment-from">@fan${userIdx}</span>
        <span class="sentiment-text">${text}</span>
      </div>
    `;
    feed.appendChild(msg);
    while (feed.children.length > 6) feed.removeChild(feed.firstChild);
  },

  // Push event-tied sentiment (called from engine on events)
  push(ball){
    let pool;
    if (ball.type === 'six'){
      const team = shortTeam(ball.battingTeam).toLowerCase();
      pool = SENTIMENT_BY_EVENT[`six_${team}`] || SENTIMENT_BY_EVENT.six_rcb;
      const msg = pool[Math.floor(Math.random() * pool.length)];
      this.add(team, msg);
    } else if (ball.type === 'wicket'){
      const bowlingTeam = (ball.battingTeam === TEAM1 ? TEAM2 : TEAM1);
      const team = shortTeam(bowlingTeam).toLowerCase();
      pool = SENTIMENT_BY_EVENT[`wicket_${team}`] || SENTIMENT_BY_EVENT.wicket_neutral;
      const msg = pool[Math.floor(Math.random() * pool.length)];
      this.add(team, msg);
      // Sometimes a neutral observer chimes in too
      if (Math.random() > 0.5){
        const n = SENTIMENT_BY_EVENT.wicket_neutral[Math.floor(Math.random() * SENTIMENT_BY_EVENT.wicket_neutral.length)];
        setTimeout(() => this.add('neutral', n), 800);
      }
    } else if (ball.type === 'four'){
      const team = shortTeam(ball.battingTeam).toLowerCase();
      pool = SENTIMENT_BY_EVENT[`four_${team}`] || SENTIMENT_BY_EVENT.four_rcb;
      const msg = pool[Math.floor(Math.random() * pool.length)];
      this.add(team, msg);
    }
  }
};

// ============================================================
// FEED (commentary line + ball strip)
// ============================================================
function generateCommentary(ball){
  if (ball.type === 'six') return `${ball.batter} <em>launches it.</em> Stunning hit off ${ball.bowler}.`;
  if (ball.type === 'four') return `${ball.batter} threads it through the gap. Pure timing.`;
  if (ball.type === 'wicket') return `<strong>${ball.bowler}</strong> strikes. ${ball.playerOut} ${ball.wicketKind}.`;
  if (ball.type === 'dot') return `Dot ball. ${ball.bowler} keeps it tight.`;
  return `${ball.runs} run${ball.runs > 1 ? 's' : ''} for ${ball.batter}.`;
}

function updateFeed(ball){
  let chipClass = '', chipText = ball.runs;
  if (ball.type === 'six'){ chipClass='six'; chipText='6'; }
  else if (ball.type === 'four'){ chipClass='four'; chipText='4'; }
  else if (ball.type === 'wicket'){ chipClass='wicket'; chipText='W'; }
  else if (ball.type === 'dot'){ chipText='·'; }

  document.getElementById('feed-current').innerHTML =
    `<span class="feed-ball ${chipClass}">${chipText}</span>${generateCommentary(ball)}`;

  document.getElementById('feed-ball-meta').textContent = `${ball.over}.${ball.ball}`;

  // Strip
  const strip = document.getElementById('feed-strip');
  const chip = document.createElement('div');
  chip.className = `feed-chip c${chipText}`;
  chip.textContent = chipText;
  strip.appendChild(chip);
  strip.scrollLeft = strip.scrollWidth;
}

// ============================================================
// SCOREBOARD update
// ============================================================
function updateScoreboard(state, ball){
  const battingShort = shortTeam(ball.battingTeam);
  const bowlingTeam = (ball.battingTeam === TEAM1) ? TEAM2 : TEAM1;
  const bowlingShort = shortTeam(bowlingTeam);

  document.getElementById('sb-bat-name').textContent = battingShort;
  document.getElementById('sb-bat-score').textContent =
    `${state.inningsScores[ball.innings].runs}/${state.inningsScores[ball.innings].wkts}`;
  document.getElementById('sb-bat-overs').textContent = `${ball.over}.${ball.ball} ov`;

  document.getElementById('sb-bowl-name').textContent = bowlingShort;
  if (ball.innings === 0){
    document.getElementById('sb-bowl-score').textContent = 'yet to bat';
    document.getElementById('sb-bowl-overs').textContent = '—';
  } else {
    document.getElementById('sb-bowl-score').textContent =
      `${state.inningsScores[0].runs}/${state.inningsScores[0].wkts}`;
    document.getElementById('sb-bowl-overs').textContent = '20.0 ov';
  }

  document.getElementById('sb-meta').textContent =
    `Live · ${ball.innings === 0 ? '1st' : '2nd'} Innings`;
}

// ============================================================
// MAIN: bowl one ball (called from app.js scheduler)
// ============================================================
function bowlBall(state){
  state.ballIdx++;
  const ball = ALL_BALLS[state.ballIdx];
  if (!ball) return;

  // Innings change?
  if (ball.innings !== state.currentInnings){
    state.currentInnings = ball.innings;
    state.wp = 50;
    showToast('Innings break · Second innings begins');
  }

  // Update score
  if (ball.type === 'wicket'){
    state.inningsScores[ball.innings].wkts++;
  } else {
    state.inningsScores[ball.innings].runs += parseInt(ball.runs) || 0;
  }
  state.balls.push(ball);

  // Update displays
  updateScoreboard(state, ball);
  updateFeed(ball);
  updateWinProbability(state, ball);

  // Presence emotion model
  Presence.update(ball, state);

  // Sentiment feed
  Sentiment.push(ball);

  // Bump wave participation on dramatic events
  if (ball.type === 'six') bumpWave(35);
  else if (ball.type === 'wicket') bumpWave(42);
  else if (ball.type === 'four') bumpWave(18);

  // Open the Theatre overlay for key moments (only one open at a time)
  if (ball.type === 'six' || ball.type === 'wicket'){
    openTheatre(ball, state);
  }

  // Co-Captain prompt (at end of over)
  maybeShowCaptainPrompt(state, ball);

  // Match Director narrative every N balls (once per over)
  if ((state.ballIdx - Director.lastNarrativeBallIdx) >= CONFIG.DIRECTOR_INTERVAL){
    Director.lastNarrativeBallIdx = state.ballIdx;
    generateNarrative(state);
  }
}

// ============================================================
// WIN PROBABILITY (simple model, mainly for narrative context)
// ============================================================
function updateWinProbability(state, ball){
  let delta = 0;
  if (ball.type === 'six')        delta = 3.5;
  else if (ball.type === 'wicket')delta = -8;
  else if (ball.type === 'four')  delta = 2;
  else if (ball.type === 'dot')   delta = -0.8;
  else                            delta = (parseInt(ball.runs) || 0) * 0.4;

  state.wp = clamp(state.wp + delta, 15, 85);
}
