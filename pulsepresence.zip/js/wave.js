/* ============================================================
   PulsePresence — STADIUM WAVE
   Hold the orb. Others are holding too. When 50%+ hold together,
   a wave ripples across all viewers (simulated visually).
============================================================ */

const Wave = {
  isUserHolding: false,
  participation: 0,        // 0-100%
  baseParticipation: 0,    // simulated others-holding baseline
  targetParticipation: 0,
  userJoinedAt: 0,
  cooldown: false,
  triggerCount: 0,         // how many waves have fired this match
};

// ============================================================
// Init wave UI events
// ============================================================
function initWave(){
  const orb = document.getElementById('wave-orb');

  const startHold = (e) => {
    if (Wave.cooldown) return;
    e.preventDefault();
    Wave.isUserHolding = true;
    Wave.userJoinedAt = Date.now();
    orb.classList.add('holding');
    document.getElementById('wave-orb-text').textContent = 'HELD';
    document.getElementById('wave-status').textContent = 'YOU\'RE IN';
    if (navigator.vibrate) navigator.vibrate(15);
  };

  const endHold = (e) => {
    if (!Wave.isUserHolding) return;
    Wave.isUserHolding = false;
    orb.classList.remove('holding');
    document.getElementById('wave-orb-text').textContent = 'HOLD';
    document.getElementById('wave-status').textContent = 'DORMANT';
  };

  orb.addEventListener('mousedown', startHold);
  orb.addEventListener('touchstart', startHold);
  orb.addEventListener('mouseup', endHold);
  orb.addEventListener('mouseleave', endHold);
  orb.addEventListener('touchend', endHold);
  orb.addEventListener('touchcancel', endHold);

  // Tick the simulation
  setInterval(tickWave, 100);
}

// ============================================================
// Simulate other viewers holding
// Baseline participation rises and falls based on match drama
// ============================================================
function tickWave(){
  // Smooth approach target
  Wave.baseParticipation += (Wave.targetParticipation - Wave.baseParticipation) * 0.08;

  // Random small jitter to feel alive
  const jitter = (Math.random() - 0.5) * 2;

  // Your contribution
  const userContrib = Wave.isUserHolding ? 4 : 0;

  Wave.participation = Math.max(0, Math.min(100, Wave.baseParticipation + jitter + userContrib));

  // Update UI
  const pct = Math.round(Wave.participation);
  document.getElementById('wave-fill').style.width = pct + '%';
  const count = Math.floor(pct * 8500); // 50% = ~425K simulated holding
  document.getElementById('wave-count').textContent = count.toLocaleString();

  // Trigger threshold
  if (Wave.participation >= 50 && !Wave.cooldown && Wave.isUserHolding){
    triggerWave();
  }

  // Decay target over time
  Wave.targetParticipation = Math.max(0, Wave.targetParticipation - 0.3);
}

// ============================================================
// Bump baseline participation (called from engine on big events)
// ============================================================
function bumpWave(amount){
  Wave.targetParticipation = Math.min(85, Wave.targetParticipation + amount);
}

// ============================================================
// FIRE THE WAVE
// ============================================================
function triggerWave(){
  Wave.cooldown = true;
  Wave.triggerCount++;

  // Visual ripple
  const ripple = document.createElement('div');
  ripple.className = 'wave-ripple fire';
  ripple.innerHTML = '<div class="wave-ripple-circle"></div>';
  document.body.appendChild(ripple);
  setTimeout(() => ripple.remove(), 2500);

  // Second + third ripple staggered
  setTimeout(() => {
    const r2 = document.createElement('div');
    r2.className = 'wave-ripple fire';
    r2.innerHTML = '<div class="wave-ripple-circle"></div>';
    document.body.appendChild(r2);
    setTimeout(() => r2.remove(), 2500);
  }, 250);

  setTimeout(() => {
    const r3 = document.createElement('div');
    r3.className = 'wave-ripple fire';
    r3.innerHTML = '<div class="wave-ripple-circle"></div>';
    document.body.appendChild(r3);
    setTimeout(() => r3.remove(), 2500);
  }, 500);

  // Haptic burst pattern
  if (navigator.vibrate) navigator.vibrate([20, 60, 20, 60, 20]);

  // Toast
  showToast('🌊 WAVE TRIGGERED · 412K phones pulsing');

  // Card celebration
  const card = document.getElementById('wave-card');
  card.classList.add('active');
  setTimeout(() => card.classList.remove('active'), 4000);

  // Cooldown 8 seconds
  setTimeout(() => {
    Wave.cooldown = false;
    Wave.targetParticipation = 0;
  }, 8000);
}
