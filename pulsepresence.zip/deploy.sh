#!/bin/bash
# PulseIPL — GCP Deploy Script
# Choose your deployment target

set -e

PROJECT_ID="${GCP_PROJECT_ID:-pulseipl-demo}"
REGION="${GCP_REGION:-asia-south1}"
SERVICE_NAME="pulseipl"

echo "🏏 PulseIPL — GCP Deployment"
echo "============================"
echo ""
echo "Pick your deployment target:"
echo "  1) Cloud Storage (cheapest, static hosting, ~30 sec)"
echo "  2) Cloud Run (containerized, auto-scaling, ~2 min)"
echo "  3) App Engine (managed, zero-config, ~3 min)"
echo ""
read -p "Choice [1/2/3]: " choice

case $choice in
  1)
    echo "📦 Deploying to Cloud Storage..."
    BUCKET="${PROJECT_ID}-pulseipl-web"
    gcloud storage buckets create gs://${BUCKET} \
      --project=${PROJECT_ID} \
      --location=${REGION} \
      --uniform-bucket-level-access || true
    gcloud storage cp index.html gs://${BUCKET}/index.html \
      --cache-control="no-cache"
    gcloud storage buckets update gs://${BUCKET} \
      --web-main-page-suffix=index.html
    gcloud storage buckets add-iam-policy-binding gs://${BUCKET} \
      --member=allUsers --role=roles/storage.objectViewer
    echo "✅ Live at: https://storage.googleapis.com/${BUCKET}/index.html"
    echo "   For custom domain + CDN, set up Cloud Load Balancer."
    ;;
  2)
    echo "🐳 Building & deploying to Cloud Run..."
    gcloud run deploy ${SERVICE_NAME} \
      --source . \
      --region ${REGION} \
      --project ${PROJECT_ID} \
      --allow-unauthenticated \
      --port 8080 \
      --memory 256Mi \
      --cpu 1 \
      --min-instances 0 \
      --max-instances 100
    echo "✅ Deployment complete."
    ;;
  3)
    echo "🚀 Deploying to App Engine..."
    gcloud app deploy app.yaml \
      --project ${PROJECT_ID} \
      --quiet
    echo "✅ Deployment complete."
    ;;
  *)
    echo "Invalid choice"
    exit 1
    ;;
esac
